# Think Before You Share

A student-created media-literacy guide about checking online claims related to school safety, responding responsibly, and protecting students' privacy.

## About the project

This is a static website built with HTML, CSS, and a small amount of vanilla JavaScript. It has no external packages or build step.

## Features

- Responsive layout for desktop and mobile screens
- Light and dark themes, with the selected theme saved in the browser
- Compact sticky navigation that responds to scrolling
- Section navigation with a current-section indicator
- Sharing checklist, response plan, warning signs, and cited references
- Keyboard skip link, visible focus styles, and reduced-motion support

## Project files

- `index.html` — page structure, content, and small interactive behaviors
- `styles.css` — layout, responsive styling, and light/dark theme design

## View the site

Open `index.html` in a browser, or publish the repository as a static site with GitHub Pages. For GitHub Pages, choose the repository's root folder as the publishing source so it can find `index.html` and `styles.css`.

## Safety note

This guide is educational and cannot verify real-time safety reports. For an immediate concern, contact trusted school staff and local emergency authorities directly, and follow official instructions.
